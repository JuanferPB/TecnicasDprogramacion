package com.myinventory.inventory;
import com.myinventory.view.Panel;
import java.io.IOException;

public class Inventory {
    public static void main(String[] args) throws IOException {
            InventoryManager inventoryManager = new InventoryManager();
            // Load products from the file at the start of the program
            try {
            inventoryManager.loadProductsFromFile("ProductsDB");
            }
            catch(IOException e){
                System.out.println("Error Opening DB");
            }
            java.awt.EventQueue.invokeLater(new Runnable() {
                public void run() {
                    new Panel(inventoryManager).setVisible(true);
                }
            });

        
 
    }
}
