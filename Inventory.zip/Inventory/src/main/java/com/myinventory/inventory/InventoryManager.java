package com.myinventory.inventory;
import java.util.*;
import java.io.*;

public class InventoryManager {
    private List<Product> products = new ArrayList<>();

    public void addProduct(Product product) {
        products.add(product);
    }
    
    public void removeProduct(int index){
        products.remove(index);
    }

    public List<Product> getProducts() {
        return products;
    }
    public void loadProductsFromFile(String filename) throws IOException {
        File file = new File(filename + ".csv");
        products = new ArrayList<>();
        if (file.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                String line = br.readLine();  // Read the header line to skip it
                while ((line = br.readLine()) != null) {
                    String[] productData = line.split(",");
                    if (productData.length >= 3) {
                        String name = productData[0];
                        double price = Double.parseDouble(productData[1]);
                        int quantity = Integer.parseInt(productData[2]);
                        products.add(new Product(name, price, quantity));
                    }
                }
            }
        } else {
            System.out.println("File not found: " + filename + " - Starting with an empty list.");
        }
    }


    public void saveProductsToFile(String filename) throws IOException {
        // Adjusting the file path to a more neutral setting
        File file = new File(filename + ".csv");
        try (PrintWriter out = new PrintWriter(new FileWriter(file))) {
            out.println("Product,Cost,Quantity");  // Writing the header line
            for (Product product : products) {
                // Each product's data is written on a new line in CSV format
                out.printf(product.getName() + "," + product.getPrice() + "," + product.getQuantity() + "\n");
            }
        } catch (IOException e) {
            System.out.println("Failed to save products to file: " + e.getMessage());
            throw e;  // Re-throwing the exception to inform the caller
        }
    }
}
